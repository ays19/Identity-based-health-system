<?php 
  $conn = mysqli_connect("localhost","root","","onenationoneidentity") or die ('cannot connect to database' . mysqli_error());
?>

